//
//  main.cpp
//  test
//
//  Created by HaoYaru on 2017/11/15.
//  Copyright © 2017年 HaoYaru. All rights reserved.
//

#include <stdio.h>
#include <string.h>
#include "macro.h"
#include "lex.h"
#include "grammar.h"
#include "error.h"
#include "semantic.h"

char ch = ' ';   // 当前字符
int num = 0;   // 存放当前的数值
int symbol = 0;   // 当前识别出的单词类型
int EF = 0;
char token[wlMAX];   // 存放单词的字符串
char line[llMAX];    // 当前行的内容
FILE *file;     // 全局的文件指针，为需要编译的文件
FILE *file_out;

char* sym_name[50];   // 需要输出的信息
char* op[50];    // 操作符和关系符的内容

symset stateBegSet;
symset item_fac_exprBegSet;

SymItem table[tablelMAX];
int tableindex[tablelMAX];
int elenum = 0;   // 符号表栈顶指针
int levelnum = 0;   // 分程序总数，及索引表栈顶指针

int ll = 0;   // 当前行长度
int cc = 0;   // character counter
int lc = 0;   // 当前行数

void init_symname()    // 初始化类别码
{
    sym_name[MAIN] = "main";
    sym_name[CONSTSY] = "const";
    sym_name[INTSY] = "int";
    sym_name[CHARSY] = "char";
    sym_name[VOIDSY] = "void";
    sym_name[IFSY] = "if";
    sym_name[DOSY] = "do";
    sym_name[WHILESY] = "while";
    sym_name[SWITCHSY] = "switch";
    sym_name[CASESY] = "case";
    sym_name[SCANFSY] = "scanf";
    sym_name[PRINTFSY] = "printf";
    sym_name[RETURNSY] = "return";
    
    sym_name[PLUS] = "plus";
    sym_name[MINUS] = "minus";
    sym_name[MULTI] = "multi";
    sym_name[DIVISION] = "division";
    sym_name[LSS] = "less";
    sym_name[LEQ] = "lequal";
    sym_name[GTR] = "greater";
    sym_name[GEQ] = "gequal";
    sym_name[NEQ] = "notequal";
    sym_name[EQL] = "equal";
    sym_name[SEMICOLON] = "semicolon";
    sym_name[BECOMES] = "becomes";
    sym_name[COMMA] = "comma";
    sym_name[LBRACK] = "lbrack";
    sym_name[RBRACK] = "rbrack";
    sym_name[LPARENT] = "lparent";
    sym_name[RPARENT] = "rparent";
    sym_name[LCURLY] = "lcurly";
    sym_name[RCURLY] = "rcurly";
    sym_name[COLON] = "colon";
    
    sym_name[IDENT] = "identifier";
    
    sym_name[CHAR] = "char";
    sym_name[STRING] = "string";
    sym_name[NUMBER] = "number";
    
    op[PLUS] = "+";
    op[MINUS] = "-";
    op[MULTI] = "*";
    op[DIVISION] = "/";
    op[LSS] = "<";
    op[LEQ] = "<=";
    op[GTR] = ">";
    op[GEQ] = ">=";
    op[NEQ] = "!=";
    op[EQL] = "==";
    op[SEMICOLON] = ";";
    op[BECOMES] = "=";
    op[COMMA] = ",";
    op[LBRACK] = "[";
    op[RBRACK] = "]";
    op[LPARENT] = "(";
    op[RPARENT] = ")";
    op[LCURLY] = "{";
    op[RCURLY] = "}";
    op[COLON] = ":";
}

int main() {
    
    char file_name[100];    // 需要读取的文件名
    char *hao_test;
    hao_test = 0;
    
    init_symname();
    
    printf("Please input a filename:\n");
    scanf("%s",file_name);
    file = fopen(file_name, "r");
        // file = fopen("15151117_test.txt", "r");
        //file_out = fopen("result.txt", "w");
    file_out = fopen("grammarresult.txt", "w");
    fprintf(file_out, "Begin Program!\n");
   /* getch();
    while(EF == 0)
    {
        getsym();
        if (symbol>=0 && symbol<=12)
            fprintf(file_out, "%d %s %s\n", order++, sym_name[symbol], token);
        else if(symbol == IDENT)
            fprintf(file_out, "%d %s %s\n", order++, sym_name[IDENT], token);
        else if(symbol == CHAR)
            fprintf(file_out, "%d %s '%s'\n", order++, sym_name[CHAR], token);
        else if(symbol == STRING)
            fprintf(file_out, "%d %s \"%s\"\n", order++, sym_name[STRING], token);
        else if(symbol == NUMBER)
            fprintf(file_out, "%d %s %s\n", order++, sym_name[NUMBER], token);
        else if(symbol != EOFSY)
        {
            fprintf(file_out, "%d %s %s %d\n", order++, sym_name[symbol], op[symbol], lc);
        }
    } */
    getch();
    program();
    
    fprintf(file_out, "END!\n");
    
    fclose(file);
    fclose(file_out);
    
    return 0;
}
