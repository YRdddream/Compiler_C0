//
//  error.h
//  test
//
//  Created by HaoYaru on 2017/11/29.
//  Copyright © 2017年 HaoYaru. All rights reserved.
//

#ifndef error_h
#define error_h

extern int lc;
extern int if_has_error;

void error(int i);

#endif /* error_h */
