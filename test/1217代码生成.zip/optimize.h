//
//  optimize.h
//  test
//
//  Created by HaoYaru on 2017/12/14.
//  Copyright © 2017年 HaoYaru. All rights reserved.
//

#ifndef optimize_h
#define optimize_h

/*
struct dagNode {
    int op;
    int left_child;
    int right_child;
    int dadnum;    // 节点孩子的数量
}dagNode;

extern int midpointer;
extern int midcnt;
extern char *MIDLIST[midcodeMAX];
extern char* mid_op[50];
extern char *out_dag[midcodeMAX];
extern int dagoutcnt;
extern char *in_dag[midcodeMAX];
extern int dagincnt;

void opt();
void func_block();
void dag_proc(int block_size);*/

#endif /* optimize_h */
